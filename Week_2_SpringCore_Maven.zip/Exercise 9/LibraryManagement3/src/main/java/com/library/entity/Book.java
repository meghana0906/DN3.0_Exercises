package com.library.entity;

public class Book {

}
