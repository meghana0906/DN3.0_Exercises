package com.library.aspect;

public class LoggingAspect {

}
