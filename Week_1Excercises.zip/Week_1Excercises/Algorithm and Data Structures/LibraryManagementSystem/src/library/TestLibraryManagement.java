package library;

public class TestLibraryManagement {
	public static void main(String[] args) {
        Library library = new Library();

        library.addBook(new Book(1, "The Great Gatsby", "F. Scott Fitzgerald"));
        library.addBook(new Book(2, "Moby Dick", "Herman Melville"));
        library.addBook(new Book(3, "To Kill a Mockingbird", "Harper Lee"));

        System.out.println("All Books in Library:");
        library.displayBooks();

        System.out.println("\nLinear Search for 'Moby Dick':");
        Book book = library.linearSearchByTitle("Moby Dick");
        System.out.println(book != null ? book : "Book not found");

        library.sortBooksByTitle();
        System.out.println("\nBinary Search for 'To Kill a Mockingbird':");
        book = library.binarySearchByTitle("To Kill a Mockingbird");
        System.out.println(book != null ? book : "Book not found");
    }
}
