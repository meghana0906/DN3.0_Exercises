package task;

public class TestTaskManagement{
	public static void main(String[] args) {
        SinglyLinkedList taskList = new SinglyLinkedList();

        Task t1 = new Task(1, "Task 1", "Incomplete");
        Task t2 = new Task(2, "Task 2", "Complete");
        Task t3 = new Task(3, "Task 3", "Incomplete");

        taskList.addTask(t1);
        taskList.addTask(t2);
        taskList.addTask(t3);

        System.out.println("Traverse Tasks:");
        taskList.traverseTasks();

        System.out.println("\nSearch for Task with ID 2:");
        System.out.println(taskList.searchTaskById(2));

        System.out.println("\nDelete Task with ID 2:");
        taskList.deleteTask(2);

        System.out.println("\nTraverse Tasks After Deletion:");
        taskList.traverseTasks();
    }
}
