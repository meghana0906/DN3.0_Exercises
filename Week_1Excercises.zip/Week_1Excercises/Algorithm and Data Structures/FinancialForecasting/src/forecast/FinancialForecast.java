package forecast;

public class FinancialForecast {
    public double predictFutureValue(double initialValue, double growthRate, int periods) {
        if (periods == 0) {
            return initialValue;
        }
        return predictFutureValue(initialValue * (1 + growthRate), growthRate, periods - 1);
    }
    
    public double predictFutureValueMemo(double initialValue, double growthRate, int periods, double[] memo) {
        if (periods == 0) {
            return initialValue;
        }
        if (memo[periods] != 0) {
            return memo[periods];
        }
        memo[periods] = predictFutureValueMemo(initialValue * (1 + growthRate), growthRate, periods - 1, memo);
        return memo[periods];
    }
    
    public static void main(String[] args) {
        FinancialForecast forecast = new FinancialForecast();
        
        double initialValue = 1000; 
        double growthRate = 0.05;
        int periods = 10; 
        double futureValue = forecast.predictFutureValue(initialValue, growthRate, periods);
        System.out.println("Predicted future value (recursive): " + futureValue);

        double[] memo = new double[periods + 1];
        double futureValueMemo = forecast.predictFutureValueMemo(initialValue, growthRate, periods, memo);
        System.out.println("Predicted future value (memoization): " + futureValueMemo);
    }
}
