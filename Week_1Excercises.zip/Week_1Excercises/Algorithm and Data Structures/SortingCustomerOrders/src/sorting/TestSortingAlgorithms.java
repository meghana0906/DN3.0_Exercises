package sorting;
import java.util.Arrays;

public class TestSortingAlgorithms {
    public static void main(String[] args) {

        Order[] orders = {
            new Order("O01", "Alice", 250.00),
            new Order("O02", "Bob", 150.00),
            new Order("O03", "Charlie", 300.00)
        };

        Order[] ordersForBubbleSort = Arrays.copyOf(orders, orders.length);
        SortingAlgorithms.bubbleSort(ordersForBubbleSort);
        System.out.println("Orders sorted by Bubble Sort:");
        for (Order order : ordersForBubbleSort) {
            System.out.println(order);
        }

        Order[] ordersForQuickSort = Arrays.copyOf(orders, orders.length);
        SortingAlgorithms.quickSort(ordersForQuickSort, 0, ordersForQuickSort.length - 1);
        System.out.println("\nOrders sorted by Quick Sort:");
        for (Order order : ordersForQuickSort) {
            System.out.println(order);
        }
    }
}

