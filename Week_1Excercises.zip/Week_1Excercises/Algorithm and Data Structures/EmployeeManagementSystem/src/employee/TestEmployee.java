package employee;

public class TestEmployee {
	public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem(10);
        Employee e1 = new Employee(1, "Alice", "Manager", 70000);
        Employee e2 = new Employee(2, "Bob", "Developer", 50000);
        Employee e3 = new Employee(3, "Charlie", "Designer", 45000);

        ems.addEmployee(e1);
        ems.addEmployee(e2);
        ems.addEmployee(e3);

        System.out.println("Traverse Employees:");
        ems.traverseEmployees();

        System.out.println("\nSearch for Employee with ID 2:");
        System.out.println(ems.searchEmployeeById(2));

        System.out.println("\nDelete Employee with ID 2:");
        ems.deleteEmployee(2);

        System.out.println("\nTraverse Employees After Deletion:");
        ems.traverseEmployees();
    }
}
