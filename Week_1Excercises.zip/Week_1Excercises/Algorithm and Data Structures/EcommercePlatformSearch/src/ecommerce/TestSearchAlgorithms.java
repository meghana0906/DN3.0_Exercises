package ecommerce;
import java.util.Arrays;

public class TestSearchAlgorithms {
    public static void main(String[] args) {

        Product[] products = {
            new Product("P01", "Laptop", "Electronics"),
            new Product("P02", "Smartphone", "Electronics"),
            new Product("P03", "Desk", "Furniture")
        };

        Arrays.sort(products, (p1, p2) -> p1.getProductId().compareTo(p2.getProductId()));

        Product foundProductLinear = SearchAlgorithms.linearSearch(products, "P02");
        System.out.println("Linear Search : " + (foundProductLinear != null ? foundProductLinear : "Product not found"));

        Product foundProductBinary = SearchAlgorithms.binarySearch(products, "P01");
        System.out.println("Binary Search : " + (foundProductBinary != null ? foundProductBinary : "Product not found"));
    }
}
