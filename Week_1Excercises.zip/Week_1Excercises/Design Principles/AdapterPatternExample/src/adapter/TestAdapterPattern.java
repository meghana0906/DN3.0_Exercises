package adapter;

public class TestAdapterPattern {
    public static void main(String[] args) {

        PaypalPaymentGateway paypalGateway = new PaypalPaymentGateway();
        PaytmPaymentGateway paytmGateway = new PaytmPaymentGateway();

        PaymentProcessor paypalProcessor = new PaypalAdapter(paypalGateway);
        PaymentProcessor paytmProcessor = new PaytmAdapter(paytmGateway);

        paypalProcessor.processPayment(150.0);
        paytmProcessor.processPayment(300.0);
    }
}

