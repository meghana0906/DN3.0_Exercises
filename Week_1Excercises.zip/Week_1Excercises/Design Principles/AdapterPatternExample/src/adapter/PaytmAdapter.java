package adapter;

public class PaytmAdapter implements PaymentProcessor{
	private PaytmPaymentGateway paytmGateway;

    public PaytmAdapter(PaytmPaymentGateway paytmGateway) {
        this.paytmGateway = paytmGateway;
    }

    @Override
    public void processPayment(double amount) {
    	paytmGateway.charge(amount);
    }
}
