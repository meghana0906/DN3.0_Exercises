package adapter;

public class PaypalAdapter implements PaymentProcessor {
    private PaypalPaymentGateway paypalGateway;

    public PaypalAdapter(PaypalPaymentGateway paypalGateway) {
        this.paypalGateway = paypalGateway;
    }

    @Override
    public void processPayment(double amount) {
        paypalGateway.makePayment(amount);
    }
}

