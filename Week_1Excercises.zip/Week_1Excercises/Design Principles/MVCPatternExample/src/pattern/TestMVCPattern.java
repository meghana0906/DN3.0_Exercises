package pattern;

public class TestMVCPattern {
    public static void main(String[] args) {
        Student student = new Student("Meghana", "S123", "A");
        StudentView studentView = new StudentView();
        StudentController studentController = new StudentController(student, studentView);

        studentController.updateView();

        studentController.setStudentName("Sita");
        studentController.setStudentGrade("B");

        studentController.updateView();
    }
}

