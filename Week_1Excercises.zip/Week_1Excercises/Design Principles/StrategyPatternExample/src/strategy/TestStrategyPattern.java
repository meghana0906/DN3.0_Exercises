package strategy;

public class TestStrategyPattern {
    public static void main(String[] args) {

        PaymentStrategy creditCardPayment = new CreditCardPayment("1234-5678-9876-5432");
        PaymentStrategy paypalPayment = new PayPalPayment("megh@gmail.com");
        PaymentContext paymentContext = new PaymentContext(creditCardPayment);
        paymentContext.executePayment(100.0);
        paymentContext = new PaymentContext(paypalPayment);
        paymentContext.executePayment(200.0);
    }
}

