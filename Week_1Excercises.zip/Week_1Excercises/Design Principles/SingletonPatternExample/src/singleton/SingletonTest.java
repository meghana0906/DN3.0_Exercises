package singleton;

public class SingletonTest {
    public static void main(String[] args) {
        Logger l1 = Logger.getInstance();
        Logger l2 = Logger.getInstance();
        l1.log("This is the first log message.");
        l2.log("This is the second log message.");
        if (l1 == l2) {
            System.out.println("Logger1 and Logger2 are same instances.");
        } else {
            System.out.println("Logger1 and Logger2 are different instances.");
        }
    }
}
