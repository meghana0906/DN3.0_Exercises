package depend;

public interface CustomerRepository {
    String findCustomerById(String id);
}

