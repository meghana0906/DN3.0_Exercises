package factory;

public abstract class DocumentFactory {
    public abstract Document createDocument();
}
